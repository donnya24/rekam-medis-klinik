-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 18, 2025 at 02:54 PM
-- Server version: 5.7.39
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `klinikku`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrasi`
--

CREATE TABLE `administrasi` (
  `id_administrasi` int(11) NOT NULL,
  `nama_administrasi` varchar(100) NOT NULL,
  `akun_administrasi` varchar(50) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `no_telepon` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat` text,
  `tanggal_bergabung` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `administrasi`
--

INSERT INTO `administrasi` (`id_administrasi`, `nama_administrasi`, `akun_administrasi`, `jenis_kelamin`, `no_telepon`, `email`, `tanggal_lahir`, `alamat`, `tanggal_bergabung`) VALUES
(1, 'Anjay', 'daffaadm', 'L', '08671572862', 'donnyk300@gmail.com', '2025-03-16', 'wer', '2025-03-16');

-- --------------------------------------------------------

--
-- Table structure for table `apoteker`
--

CREATE TABLE `apoteker` (
  `id_apoteker` int(11) NOT NULL,
  `nama_apoteker` varchar(100) NOT NULL,
  `akun_apoteker` varchar(50) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `no_telepon` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat` text,
  `tanggal_bergabung` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `apoteker`
--

INSERT INTO `apoteker` (`id_apoteker`, `nama_apoteker`, `akun_apoteker`, `jenis_kelamin`, `no_telepon`, `email`, `tanggal_lahir`, `alamat`, `tanggal_bergabung`) VALUES
(1, 'ggqq', 'apoteker1', 'L', '456', 'donnyk300@gmail.com', '2025-03-16', 'rty', '2025-03-16');

-- --------------------------------------------------------

--
-- Table structure for table `catatan_medis`
--

CREATE TABLE `catatan_medis` (
  `id_catatan` int(11) NOT NULL,
  `id_pasien` int(11) DEFAULT NULL,
  `id_dokter` int(11) DEFAULT NULL,
  `id_reservasi` int(11) DEFAULT NULL,
  `diagnosis` text,
  `rencana_perawatan` text,
  `catatan_pasca_pemeriksaan` text,
  `tanggal_periksa` date DEFAULT NULL,
  `id_perawat` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `catatan_medis`
--

INSERT INTO `catatan_medis` (`id_catatan`, `id_pasien`, `id_dokter`, `id_reservasi`, `diagnosis`, `rencana_perawatan`, `catatan_pasca_pemeriksaan`, `tanggal_periksa`, `id_perawat`) VALUES
(4, NULL, NULL, 18, 'trtrtr', 'RAWAT JALAN', '2ddc', '2025-03-16', 3),
(5, NULL, NULL, 18, 'wqewfd', 'sd', 'sad', '2025-03-16', NULL),
(7, NULL, NULL, 18, 'vsdds', 'dvvssv', 'vv', '2025-03-16', 4),
(8, NULL, NULL, 19, 'sgrs', 'wrgwr', 'rger', '2025-03-16', 4);

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE `dokter` (
  `id_dokter` int(11) NOT NULL,
  `nama_dokter` varchar(100) NOT NULL,
  `akun_dokter` varchar(50) NOT NULL,
  `jenis_kelamin` enum('L','P') DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat` text,
  `tanggal_bergabung` date DEFAULT NULL,
  `spesialis` varchar(50) DEFAULT NULL,
  `no_telepon` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`id_dokter`, `nama_dokter`, `akun_dokter`, `jenis_kelamin`, `tanggal_lahir`, `alamat`, `tanggal_bergabung`, `spesialis`, `no_telepon`, `email`) VALUES
(19, 'Donny', 'dokter1', 'P', '2025-03-16', 'sdretrty', '2025-03-16', 'THT', '08671572862', 'donnyk300@gmail.com'),
(20, 'andik', 'dokter2', 'P', '2025-03-16', 'eww', '2025-03-16', 'werf', '08671572862', 'donnyk300@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `hasil_pemeriksaan`
--

CREATE TABLE `hasil_pemeriksaan` (
  `id_hasil` int(11) NOT NULL,
  `id_reservasi` int(11) DEFAULT NULL,
  `id_pasien` int(11) DEFAULT NULL,
  `id_dokter` int(11) DEFAULT NULL,
  `id_obat` int(11) DEFAULT NULL,
  `tanggal_pemeriksaan` date DEFAULT NULL,
  `jenis_pemeriksaan` varchar(225) NOT NULL,
  `hasil_pemeriksaan` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hasil_pemeriksaan`
--

INSERT INTO `hasil_pemeriksaan` (`id_hasil`, `id_reservasi`, `id_pasien`, `id_dokter`, `id_obat`, `tanggal_pemeriksaan`, `jenis_pemeriksaan`, `hasil_pemeriksaan`) VALUES
(3, 18, NULL, NULL, 11, '2025-03-16', 'Telinga', 'qwerg'),
(4, 19, NULL, NULL, 11, '2025-03-16', 'ddsds', 'fdbdfb');

-- --------------------------------------------------------

--
-- Table structure for table `obat`
--

CREATE TABLE `obat` (
  `id_obat` int(11) NOT NULL,
  `nama_obat` varchar(100) NOT NULL,
  `jenis_obat` varchar(50) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  `harga` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `obat`
--

INSERT INTO `obat` (`id_obat`, `nama_obat`, `jenis_obat`, `stok`, `harga`) VALUES
(11, 'Paratusin', 'Tablet', 30, '10.00'),
(12, 'Bodrexin', 'sirup', 22, '11000.00');

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

CREATE TABLE `pasien` (
  `id_pasien` int(11) NOT NULL,
  `nama_pasien` varchar(100) NOT NULL,
  `alamat` text,
  `tanggal_lahir` date DEFAULT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `no_telepon` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pasien`
--

INSERT INTO `pasien` (`id_pasien`, `nama_pasien`, `alamat`, `tanggal_lahir`, `jenis_kelamin`, `no_telepon`) VALUES
(33, 'Donny', 'fbn', '2025-03-12', 'L', '12'),
(34, 'qq', 'gfgjh', '2025-03-12', 'L', '2345'),
(35, 'wertyu', 'tyj', '2025-03-12', 'L', '123'),
(36, 'assss', 'ghj', '2025-04-18', 'L', '0987654311');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_pasien` int(11) DEFAULT NULL,
  `id_hasil` int(11) DEFAULT NULL,
  `id_obat` int(11) DEFAULT NULL,
  `id_perawatan` int(11) DEFAULT NULL,
  `metode_pembayaran` enum('Tunai','Transfer','Kartu Kredit') NOT NULL,
  `total_harga` decimal(10,2) NOT NULL,
  `bayar` decimal(10,2) NOT NULL,
  `kembali` decimal(10,2) NOT NULL,
  `jumlah_obat` int(11) NOT NULL,
  `jumlah_perawatan` int(11) NOT NULL,
  `tanggal_pembayaran` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_reservasi` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `perawat`
--

CREATE TABLE `perawat` (
  `id_perawat` int(11) NOT NULL,
  `nama_perawat` varchar(100) NOT NULL,
  `akun_perawat` varchar(50) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `no_telepon` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat` text,
  `tanggal_bergabung` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perawat`
--

INSERT INTO `perawat` (`id_perawat`, `nama_perawat`, `akun_perawat`, `jenis_kelamin`, `no_telepon`, `email`, `tanggal_lahir`, `alamat`, `tanggal_bergabung`) VALUES
(3, 'Asj', 'alivaperawat', 'P', '08671572862', 'donnyk300@gmail.com', '2025-03-16', 'mmmm', '2025-03-16'),
(4, 'anjay kau', 'anjayrawat', 'L', '122', 'donnyWo@gmail.com', '2025-03-16', 'edf', '2025-03-16');

-- --------------------------------------------------------

--
-- Table structure for table `perawatan`
--

CREATE TABLE `perawatan` (
  `id_perawatan` int(11) NOT NULL,
  `id_dokter` int(11) DEFAULT NULL,
  `id_ruangan` int(11) DEFAULT NULL,
  `nama_perawatan` varchar(255) NOT NULL,
  `harga_perawatan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `perawatan`
--

INSERT INTO `perawatan` (`id_perawatan`, `id_dokter`, `id_ruangan`, `nama_perawatan`, `harga_perawatan`) VALUES
(6, 19, 1, 'Telinga Kotor', '111111'),
(7, 20, 2, 'ngne', '111111');

-- --------------------------------------------------------

--
-- Table structure for table `reservasi`
--

CREATE TABLE `reservasi` (
  `id_reservasi` int(11) NOT NULL,
  `id_pasien` int(11) DEFAULT NULL,
  `id_dokter` int(11) DEFAULT NULL,
  `id_ruangan` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `waktu` time DEFAULT NULL,
  `id_perawatan` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservasi`
--

INSERT INTO `reservasi` (`id_reservasi`, `id_pasien`, `id_dokter`, `id_ruangan`, `tanggal`, `waktu`, `id_perawatan`) VALUES
(18, 33, 19, 1, '2025-03-16', '15:44:49', 6),
(19, 35, 20, 2, '2025-03-16', '17:26:14', 7),
(20, 34, 20, 2, '2025-04-18', '11:40:45', 7),
(21, 36, 19, 1, '2025-04-18', '11:42:09', 6);

-- --------------------------------------------------------

--
-- Table structure for table `ruangan`
--

CREATE TABLE `ruangan` (
  `id_ruangan` int(11) NOT NULL,
  `nama_ruangan` varchar(50) NOT NULL,
  `kapasitas` int(11) NOT NULL,
  `status` enum('Tersedia','Tidak Tersedia') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ruangan`
--

INSERT INTO `ruangan` (`id_ruangan`, `nama_ruangan`, `kapasitas`, `status`) VALUES
(1, 'Anggrek 1 (VIP)', 33, 'Tersedia'),
(2, 'Flamboyan 2', 20, 'Tersedia');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_obat`
--

CREATE TABLE `transaksi_obat` (
  `id_transaksi` int(11) NOT NULL,
  `id_obat` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_perawatan`
--

CREATE TABLE `transaksi_perawatan` (
  `id_transaksi` int(11) NOT NULL,
  `id_pasien` int(11) NOT NULL,
  `id_perawatan` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi_perawatan`
--

INSERT INTO `transaksi_perawatan` (`id_transaksi`, `id_pasien`, `id_perawatan`, `jumlah`, `tanggal`) VALUES
(2, 35, 7, 1, '2025-03-16');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `no_telepon` varchar(15) NOT NULL,
  `alamat` text NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','administrasi','dokter','perawat','apoteker') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `nama_lengkap`, `no_telepon`, `alamat`, `password`, `role`) VALUES
(1, 'donny', 'donny a', '0865726300', 'Jaohh', 'admin1', 'admin'),
(2, 'daffa', 'daffa bayu', '087572972573', 'pluto', 'admin2', 'admin'),
(3, 'aliva', 'aliva wahyu', '08647356464', 'marsd', 'admin3', 'admin'),
(4, 'lana', 'lana zelda', '085675357585', 'adoh', 'admin4', 'admin'),
(12, 'daffaadm', 'Daffa Bayu', '0987654311', 'eaaa', '123', 'administrasi'),
(13, 'alivaperawat', 'Alivaaaaaaaaaa', '0987656776', 'dfyuijb', '123', 'perawat'),
(14, 'apoteker1', 'Lana Lo ikiih', '098767899', 'rtyut', '1234', 'apoteker'),
(16, 'dokter1', 'Donny Andika', '08671572862', 'qwer', '123', 'dokter'),
(17, 'dokter2', 'anjaymabar', '08671572862', 'qwer', '123', 'dokter'),
(18, 'anjayrawat', 'Donny Andika', '08671572862', 'egergge', '123', 'perawat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrasi`
--
ALTER TABLE `administrasi`
  ADD PRIMARY KEY (`id_administrasi`);

--
-- Indexes for table `apoteker`
--
ALTER TABLE `apoteker`
  ADD PRIMARY KEY (`id_apoteker`);

--
-- Indexes for table `catatan_medis`
--
ALTER TABLE `catatan_medis`
  ADD PRIMARY KEY (`id_catatan`),
  ADD KEY `id_pasien` (`id_pasien`),
  ADD KEY `id_dokter` (`id_dokter`),
  ADD KEY `id_reservasi` (`id_reservasi`),
  ADD KEY `fk_perawat` (`id_perawat`);

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
  ADD PRIMARY KEY (`id_dokter`);

--
-- Indexes for table `hasil_pemeriksaan`
--
ALTER TABLE `hasil_pemeriksaan`
  ADD PRIMARY KEY (`id_hasil`),
  ADD UNIQUE KEY `id_reservasi` (`id_reservasi`),
  ADD UNIQUE KEY `id_pasien` (`id_pasien`),
  ADD UNIQUE KEY `id_dokter` (`id_dokter`),
  ADD UNIQUE KEY `id_obat` (`id_obat`,`id_dokter`,`id_pasien`,`id_reservasi`) USING BTREE;

--
-- Indexes for table `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`id_obat`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id_pasien`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD UNIQUE KEY `id_reservasi` (`id_reservasi`),
  ADD UNIQUE KEY `id_hasil` (`id_hasil`,`id_obat`,`id_pasien`,`id_perawatan`) USING BTREE,
  ADD UNIQUE KEY `id_perawatan` (`id_perawatan`,`id_pasien`,`id_hasil`,`id_obat`) USING BTREE,
  ADD KEY `id_obat` (`id_obat`),
  ADD KEY `id_pasien` (`id_pasien`,`id_hasil`,`id_obat`,`id_perawatan`) USING BTREE,
  ADD KEY `id_reservasi_2` (`id_reservasi`);

--
-- Indexes for table `perawat`
--
ALTER TABLE `perawat`
  ADD PRIMARY KEY (`id_perawat`),
  ADD UNIQUE KEY `akun_perawat` (`akun_perawat`);

--
-- Indexes for table `perawatan`
--
ALTER TABLE `perawatan`
  ADD PRIMARY KEY (`id_perawatan`),
  ADD KEY `id_dokter` (`id_dokter`) USING BTREE,
  ADD KEY `id_ruangan` (`id_ruangan`) USING BTREE;

--
-- Indexes for table `reservasi`
--
ALTER TABLE `reservasi`
  ADD PRIMARY KEY (`id_reservasi`),
  ADD UNIQUE KEY `id_pasien` (`id_pasien`,`id_dokter`,`id_perawatan`,`id_ruangan`) USING BTREE,
  ADD UNIQUE KEY `id_perawatan` (`id_perawatan`,`id_pasien`,`id_dokter`,`id_ruangan`) USING BTREE,
  ADD UNIQUE KEY `id_dokter` (`id_dokter`,`id_pasien`,`id_ruangan`,`id_perawatan`) USING BTREE,
  ADD UNIQUE KEY `id_ruangan` (`id_ruangan`,`id_pasien`,`id_dokter`,`id_perawatan`) USING BTREE;

--
-- Indexes for table `ruangan`
--
ALTER TABLE `ruangan`
  ADD PRIMARY KEY (`id_ruangan`);

--
-- Indexes for table `transaksi_obat`
--
ALTER TABLE `transaksi_obat`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_obat` (`id_obat`);

--
-- Indexes for table `transaksi_perawatan`
--
ALTER TABLE `transaksi_perawatan`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD UNIQUE KEY `id_pasien` (`id_pasien`),
  ADD KEY `id_perawatan` (`id_perawatan`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrasi`
--
ALTER TABLE `administrasi`
  MODIFY `id_administrasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `apoteker`
--
ALTER TABLE `apoteker`
  MODIFY `id_apoteker` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `catatan_medis`
--
ALTER TABLE `catatan_medis`
  MODIFY `id_catatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `dokter`
--
ALTER TABLE `dokter`
  MODIFY `id_dokter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `hasil_pemeriksaan`
--
ALTER TABLE `hasil_pemeriksaan`
  MODIFY `id_hasil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `obat`
--
ALTER TABLE `obat`
  MODIFY `id_obat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id_pasien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `perawat`
--
ALTER TABLE `perawat`
  MODIFY `id_perawat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `perawatan`
--
ALTER TABLE `perawatan`
  MODIFY `id_perawatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `reservasi`
--
ALTER TABLE `reservasi`
  MODIFY `id_reservasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `ruangan`
--
ALTER TABLE `ruangan`
  MODIFY `id_ruangan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transaksi_obat`
--
ALTER TABLE `transaksi_obat`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transaksi_perawatan`
--
ALTER TABLE `transaksi_perawatan`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `catatan_medis`
--
ALTER TABLE `catatan_medis`
  ADD CONSTRAINT `catatan_medis_ibfk_1` FOREIGN KEY (`id_pasien`) REFERENCES `pasien` (`id_pasien`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `catatan_medis_ibfk_2` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id_dokter`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `catatan_medis_ibfk_3` FOREIGN KEY (`id_reservasi`) REFERENCES `reservasi` (`id_reservasi`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_perawat` FOREIGN KEY (`id_perawat`) REFERENCES `perawat` (`id_perawat`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hasil_pemeriksaan`
--
ALTER TABLE `hasil_pemeriksaan`
  ADD CONSTRAINT `hasil_pemeriksaan_ibfk_1` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id_dokter`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hasil_pemeriksaan_ibfk_2` FOREIGN KEY (`id_reservasi`) REFERENCES `reservasi` (`id_reservasi`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hasil_pemeriksaan_ibfk_3` FOREIGN KEY (`id_pasien`) REFERENCES `pasien` (`id_pasien`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hasil_pemeriksaan_ibfk_4` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id_obat`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`id_pasien`) REFERENCES `pasien` (`id_pasien`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pembayaran_ibfk_2` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id_obat`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pembayaran_ibfk_3` FOREIGN KEY (`id_hasil`) REFERENCES `hasil_pemeriksaan` (`id_hasil`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pembayaran_ibfk_4` FOREIGN KEY (`id_perawatan`) REFERENCES `perawatan` (`id_perawatan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `perawatan`
--
ALTER TABLE `perawatan`
  ADD CONSTRAINT `fk_perawatan_dokter` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id_dokter`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_perawatan_ruangan` FOREIGN KEY (`id_ruangan`) REFERENCES `ruangan` (`id_ruangan`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `perawatan_ibfk_1` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id_dokter`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `perawatan_ibfk_2` FOREIGN KEY (`id_ruangan`) REFERENCES `ruangan` (`id_ruangan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reservasi`
--
ALTER TABLE `reservasi`
  ADD CONSTRAINT `reservasi_ibfk_1` FOREIGN KEY (`id_pasien`) REFERENCES `pasien` (`id_pasien`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `reservasi_ibfk_2` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id_dokter`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `reservasi_ibfk_4` FOREIGN KEY (`id_perawatan`) REFERENCES `perawatan` (`id_perawatan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `reservasi_ibfk_5` FOREIGN KEY (`id_ruangan`) REFERENCES `ruangan` (`id_ruangan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transaksi_obat`
--
ALTER TABLE `transaksi_obat`
  ADD CONSTRAINT `transaksi_obat_ibfk_1` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id_obat`);

--
-- Constraints for table `transaksi_perawatan`
--
ALTER TABLE `transaksi_perawatan`
  ADD CONSTRAINT `transaksi_perawatan_ibfk_1` FOREIGN KEY (`id_perawatan`) REFERENCES `perawatan` (`id_perawatan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_perawatan_ibfk_2` FOREIGN KEY (`id_pasien`) REFERENCES `pasien` (`id_pasien`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
